import DetailResto from '../views/pages/detail-resto';
import ExploreResto from '../views/pages/explore-resto';
import FavoriteResto from '../views/pages/favorite-resto';

const routes = {
  '/': ExploreResto, // default page
  '/explore-resto': ExploreResto,
  '/favorite': FavoriteResto,
  '/detail/:id': DetailResto,
};

export default routes;
