import CONFIG from '../../globals/config';

const createRestoDetailTemplate = (restaurant) => `
<h2 class="resto__name">${restaurant.restaurant.name}</h2>
<img class="resto__poster" alt=" image ${restaurant.restaurant.name} src="${CONFIG.BASE_IMAGE_URL + restaurant.restaurant.pictureId}"  crossorigin="anonymous" />
    <div class="resto__info">
        <h3>Informasi Restoran</h3>
        <h4>Kota</h4>
        <p>${restaurant.restaurant.city}</p>
        <h4>Deskripsi</h4>
        <p>${restaurant.restaurant.description}</p>
        <h4>Menu Makanan</h4>
        <p>${restaurant.restaurant.menus.foods.map((food) => food.name).join(', ')}</p>
        <h4>Menu Minuman</h4>
        <p>${restaurant.restaurant.menus.drinks.map((drink) => drink.name).join(', ')}</p>
    </div>
    <div class="customer-reviews">
        <h4>Customer Reviews</h4>${restaurant.restaurant.customerReviews.map((review) => `
            <div class="review">
                <p>${review.review}</p>
                
            </div>`).join('')}
    </div>
    <div class="movie__overview">
        <h3>Overview</h3>
        <p>${restaurant.restaurant.rating}</p>
    </div>`;
const createRestoItemTemplate = (restaurants) => `
<article class="post-item">
      <img class="resto-picts" alt=" image ${restaurants.name}" 
      src="./images/placeholder-large.jpg" 
      data-src="${restaurants.pictureId ? CONFIG.BASE_IMAGE_URL + restaurants.pictureId : 'https://picsum.photos/id/666/800/450?grayscale'}" 
      crossorigin="anonymous" >
      <div class="resto-desc">
        <h3 class="resto-item__title" tabindex="0">${restaurants.name}</h3>
        <h4>Kota: ${restaurants.city}</h4>
        <h5 class="text-rating"> Rating this cafe: ${restaurants.rating}</a></h5>
        <p class"resto-item__description">${restaurants.description}</p>
      </div>
      <div class="resto-item__content">
      <h3><a href="/#/detail/${restaurants.id}">${restaurants.name}</a></h3>
      <p>${restaurants.description}</p>
    </div>
    </article>
`;

export { createRestoItemTemplate, createRestoDetailTemplate };
