import RestoDbSource from '../../data/restaurant-dicoding';
import UrlParser from '../../routes/url-parser';
import { createRestoDetailTemplate } from '../templates/template-creator';

const DetailResto = {
  async render() {
    return `
    <div id="restaurant" class="restaurant"></div>`;
  },

  async afterRender() {
    // Fungsi ini akan dipanggil setelah render()
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restaurant = await RestoDbSource.detailResto(url.id);
    const restoContainer = document.querySelector('#restaurant');
    restoContainer.innerHTML = createRestoDetailTemplate(restaurant);
  },
};

export default DetailResto;
