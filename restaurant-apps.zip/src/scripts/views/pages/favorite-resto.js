import RestoDbSource from '../../data/restaurant-dicoding';

const FavoriteResto = {
  async render() {
    return `
          <h2> Favorite Restaurant </h2>`;
  },

  async afterRender() {
    // Fungsi ini akan dipanggil setelah render()
    const resto = await RestoDbSource.restoList();
    console.log(resto);
  },
};

export default FavoriteResto;
