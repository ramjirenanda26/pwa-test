import RestoDbSource from '../../data/restaurant-dicoding';
import { createRestoItemTemplate } from '../templates/template-creator';

const ExploreResto = {
  async render() {
    return `
    <section class="restaurant-content">
        <h1 class="judul">Explore Restaurant</h1>
        <div class="post" id="resto"></div>
      </section>`;
  },

  async afterRender() {
    const resto = await RestoDbSource.restoList();
    const restoContainer = document.querySelector('#resto');
    // eslint-disable-next-line no-shadow
    resto.forEach((resto) => {
      restoContainer.innerHTML += createRestoItemTemplate(resto);
    });

    // Fungsi ini akan dipanggil setelah render()
  },
};

export default ExploreResto;
